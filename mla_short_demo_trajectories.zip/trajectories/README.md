# mla_short demo trajectories

Three starter source paths: circle, rounded square, and figure eight.

- Frame: `plane1`; the path is centered at `[0, 0]`.
- Height: 9 cm above the sensor plane, encoded as `tip_z_m=-0.09` because plane1 +Z points into the board.
- Size: 5 cm radius/half extent (about 10 cm across).
- Orientation: fixed quaternion `[0, 0, 0, 1]` in xyzw order.
- Timing: 0.1 s samples; 3 s stationary start, 54 s for one smooth loop, then 3 s explicit hold.
- The square uses rounded corners to keep turns smooth.

These CSVs are source waypoints, not validated recordings. Compile each under `mla_short` before using it:

```bash
ros2 run hx_waypoint_tools tipdraw build-recording --env mla_short --trajectory mla_short_demo_circle_z09 --compile-only
ros2 run hx_waypoint_tools tipdraw build-recording --env mla_short --trajectory mla_short_demo_rounded_square_z09 --compile-only
ros2 run hx_waypoint_tools tipdraw build-recording --env mla_short --trajectory mla_short_demo_figure8_z09 --compile-only
```