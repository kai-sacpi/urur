# mla_short height-varying circle trajectories

Two source trajectories that use the same 3D circular shape and vary height smoothly during one lap:

| File | Diameter | XY radius | Height above sensor plane |
|---|---:|---:|---:|
| `mla_short_demo_depth_loop_w10cm_z09_to_z10.csv` | 10 cm | 5 cm | 9 cm to 10 cm and back |
| `mla_short_demo_depth_loop_w20cm_z09_to_z10.csv` | 20 cm | 10 cm | 9 cm to 10 cm and back |

Both are centered at `plane1 [0,0]`, use fixed orientation `xyzw=[0,0,0,1]`, 0.1 s samples, a 3 s stationary start, a 54 s minimum-jerk loop, and a 3 s final hold (60 s total, 601 points). Because local `plane1 -Z` points physically upward, heights 9–10 cm are encoded as `tip_z_m=-0.09` to `-0.10`. The path moves away from the board during its height excursion.

These are new source paths and have not yet been compiled or validated in the Ubuntu simulator. Compile them separately under `mla_short`:

```bash
ros2 run hx_waypoint_tools tipdraw build-recording --env mla_short --trajectory mla_short_demo_depth_loop_w10cm_z09_to_z10 --compile-only
ros2 run hx_waypoint_tools tipdraw build-recording --env mla_short --trajectory mla_short_demo_depth_loop_w20cm_z09_to_z10 --compile-only
```
