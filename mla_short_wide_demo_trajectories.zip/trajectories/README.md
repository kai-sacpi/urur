# mla_short larger-area demo trajectories

本组为原三条轨迹的 XY 尺寸 2 倍版本，形状、姿态、高度和时间结构保持一致。

- 轨迹中心：plane1 原点。
- 平面覆盖范围：X/Y 各约 -0.10 m 至 +0.10 m，即约 20 cm × 20 cm。
- 圆形半径：0.10 m；圆角方形半边长：0.10 m；8 字形包络：约 20 cm × 20 cm。
- 高度：tip_z_m=-0.09，与原组一致。
- 姿态：固定 [0, 0, 0, 1]（xyzw）。
- 时间：每 0.1 s 采样，总时长 60 s；起始静止、绘制一圈、末尾保持，与原组一致。
- 蓝色底板按环境配置为 40 cm × 40 cm；此组轨迹在 XY 边缘约留 10 cm。实际可行性仍须在当前环境执行 compile-only 和 mock 仿真检查。

文件是 source waypoints，不是可直接播放的 validated recording。

ros2 run hx_waypoint_tools tipdraw build-recording --env mla_short --trajectory mla_short_demo_circle_w20cm_z09 --compile-only
ros2 run hx_waypoint_tools tipdraw build-recording --env mla_short --trajectory mla_short_demo_rounded_square_w20cm_z09 --compile-only
ros2 run hx_waypoint_tools tipdraw build-recording --env mla_short --trajectory mla_short_demo_figure8_w20cm_z09 --compile-only